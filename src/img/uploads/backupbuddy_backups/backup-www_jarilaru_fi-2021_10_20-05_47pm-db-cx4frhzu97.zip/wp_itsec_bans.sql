CREATE TABLE `wp_itsec_bans` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `host` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ip',  `created_at` datetime NOT NULL,  `actor_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `actor_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',  PRIMARY KEY (`id`),  UNIQUE KEY `host` (`host`),  KEY `actor` (`actor_type`,`actor_id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_itsec_bans` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_itsec_bans` VALUES('1', '112.134.231.143', 'ip', '2021-10-05 01:10:26', 'lockout_module', 'brute_force', '');
INSERT INTO `wp_itsec_bans` VALUES('2', '112.134.227.211', 'ip', '2021-10-05 03:24:38', 'lockout_module', 'brute_force', '');
/*!40000 ALTER TABLE `wp_itsec_bans` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
