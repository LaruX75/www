CREATE TABLE `wp_give_sessions` (  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,  `session_expiry` bigint(20) unsigned NOT NULL,  PRIMARY KEY (`session_key`),  UNIQUE KEY `session_id` (`session_id`)) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_give_sessions` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_give_sessions` VALUES('16', '90248c4a56c53d2fe090ffacd04be79b', 'a:1:{s:10:\"give_email\";s:17:\"jari.laru@oulu.fi\";}', '1641825285');
/*!40000 ALTER TABLE `wp_give_sessions` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
