CREATE TABLE `wp_pmxi_files` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `import_id` bigint(20) unsigned NOT NULL,  `name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_pmxi_files` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `wp_pmxi_files` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
