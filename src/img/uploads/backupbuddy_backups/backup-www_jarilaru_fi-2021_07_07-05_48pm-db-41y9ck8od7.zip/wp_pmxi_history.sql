CREATE TABLE `wp_pmxi_history` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `import_id` bigint(20) unsigned NOT NULL,  `type` enum('manual','processing','trigger','continue','cli','') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',  `time_run` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  `summary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_pmxi_history` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `wp_pmxi_history` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
