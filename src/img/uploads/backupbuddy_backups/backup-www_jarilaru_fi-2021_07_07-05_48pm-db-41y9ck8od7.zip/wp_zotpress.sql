CREATE TABLE `wp_zotpress` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `account_type` varchar(10) NOT NULL,  `api_user_id` varchar(10) NOT NULL,  `public_key` varchar(28) DEFAULT NULL,  `nickname` varchar(200) DEFAULT NULL,  `version` varchar(10) DEFAULT '5.1',  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_zotpress` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_zotpress` VALUES('1', 'users', '7316395', '1kZnrrnaTOwG5Lx9EKJ9sDr0', 'JariLaru', '5.1');
/*!40000 ALTER TABLE `wp_zotpress` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
