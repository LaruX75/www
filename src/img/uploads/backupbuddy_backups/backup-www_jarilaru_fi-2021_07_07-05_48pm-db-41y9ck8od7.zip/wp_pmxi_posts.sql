CREATE TABLE `wp_pmxi_posts` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `post_id` bigint(20) unsigned NOT NULL,  `import_id` bigint(20) unsigned NOT NULL,  `unique_key` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `product_key` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `iteration` bigint(20) NOT NULL DEFAULT 0,  `specified` tinyint(1) NOT NULL DEFAULT 0,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_pmxi_posts` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `wp_pmxi_posts` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
