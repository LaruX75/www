CREATE TABLE `wp_zotpress_zoteroItemImages` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `api_user_id` varchar(50) NOT NULL,  `item_key` varchar(50) NOT NULL,  `image` text DEFAULT NULL,  PRIMARY KEY (`api_user_id`,`item_key`),  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_zotpress_zoteroItemImages` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `wp_zotpress_zoteroItemImages` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
