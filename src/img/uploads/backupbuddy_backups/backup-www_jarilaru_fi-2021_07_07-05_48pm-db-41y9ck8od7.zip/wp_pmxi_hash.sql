CREATE TABLE `wp_pmxi_hash` (  `hash` binary(16) NOT NULL,  `post_id` bigint(20) unsigned NOT NULL,  `import_id` smallint(5) unsigned NOT NULL,  `post_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',  PRIMARY KEY (`hash`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_pmxi_hash` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `wp_pmxi_hash` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
