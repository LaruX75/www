CREATE TABLE `wp_give_log` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `log_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,  `category` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,  `source` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,  `date` datetime NOT NULL,  PRIMARY KEY (`id`),  KEY `log_type` (`log_type`),  KEY `category` (`category`),  KEY `source` (`source`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_give_log` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `wp_give_log` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
