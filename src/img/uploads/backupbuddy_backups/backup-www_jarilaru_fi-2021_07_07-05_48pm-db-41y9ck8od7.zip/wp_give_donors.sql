CREATE TABLE `wp_give_donors` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `user_id` bigint(20) NOT NULL,  `email` varchar(255) NOT NULL,  `name` mediumtext NOT NULL,  `purchase_value` mediumtext NOT NULL,  `purchase_count` bigint(20) NOT NULL,  `payment_ids` longtext NOT NULL,  `date_created` datetime NOT NULL,  `token` varchar(255) NOT NULL,  `verify_key` varchar(255) NOT NULL,  `verify_throttle` datetime NOT NULL,  PRIMARY KEY (`id`),  UNIQUE KEY `email` (`email`),  KEY `user` (`user_id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_give_donors` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_give_donors` VALUES('1', '1', 'jari.laru@oulu.fi', 'Jari Laru', '270.000000', '3', '1213,1576,1579', '2021-01-17 18:46:16', '', '', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `wp_give_donors` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
