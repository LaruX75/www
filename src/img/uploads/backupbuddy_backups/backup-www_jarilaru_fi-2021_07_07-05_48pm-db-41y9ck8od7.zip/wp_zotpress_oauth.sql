CREATE TABLE `wp_zotpress_oauth` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `cache` longtext NOT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_zotpress_oauth` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_zotpress_oauth` VALUES('1', 'empty');
/*!40000 ALTER TABLE `wp_zotpress_oauth` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
