CREATE TABLE `wp_pmxi_templates` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `options` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `scheduled` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `is_keep_linebreaks` tinyint(1) NOT NULL DEFAULT 0,  `is_leave_html` tinyint(1) NOT NULL DEFAULT 0,  `fix_characters` tinyint(1) NOT NULL DEFAULT 0,  `meta` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_pmxi_templates` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `wp_pmxi_templates` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
